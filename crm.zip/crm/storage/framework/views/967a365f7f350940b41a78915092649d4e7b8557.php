<!-- resources/views/companies/index.blade.php -->
<?php


use Illuminate\Support\Facades\Storage;
?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Companies</h1>

        <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary mb-3">Create Company</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Logo</th>
                    <th>Website</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($company->name); ?></td>
                        <td><?php echo e($company->email); ?></td>
                        <td><img src="<?php echo e(asset('storage/' . str_replace('public/', '', $company->logo))); ?>" alt="Company Logo" width="100"></td>
                        <td><?php echo e($company->website); ?></td>
                        <td>
                            <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                            <form action="<?php echo e(route('companies.destroy', $company->id)); ?>" method="POST" style="display: inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
</tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <div class="pagination justify-content-center">
        <?php echo e($companies->links('pagination::bootstrap-4')); ?>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mini-crm\resources\views/companies/index.blade.php ENDPATH**/ ?>