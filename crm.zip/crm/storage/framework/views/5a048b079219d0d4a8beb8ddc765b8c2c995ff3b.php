

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Employees</h2>

        <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-primary mb-3">Add Employee</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Company</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($employee->first_name); ?></td>
                        <td><?php echo e($employee->last_name); ?></td>
                        <td><?php echo e($employee->company->name); ?></td>
                        <td><?php echo e($employee->email); ?></td>
                        <td><?php echo e($employee->phone); ?></td>
                        <td>
                            <a href="<?php echo e(route('employees.edit', $employee->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <form action="<?php echo e(route('employees.destroy', $employee->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this employee?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="pagination justify-content-center">
        <?php echo e($employees->links('pagination::bootstrap-4')); ?>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mini-crm\resources\views/employees/index.blade.php ENDPATH**/ ?>